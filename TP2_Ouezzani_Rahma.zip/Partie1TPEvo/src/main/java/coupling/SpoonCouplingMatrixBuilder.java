package coupling;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * TP2 – Exercice 3 (suite)
 *
 * Cette classe lit le fichier de couplage généré par Spoon (spoon-coupling.csv),
 * calcule la matrice de couplage normalisée entre les classes,
 * puis exporte les résultats au format CSV et DOT.
 */
public class SpoonCouplingMatrixBuilder {

    /** Représente une relation entre deux classes (source → destination) */
    public record Edge(String src, String dest) {}

    public static void main(String[] args) throws IOException {
        // 1) Lecture du graphe de couplage produit par Spoon
        Path inputFile = Paths.get("target/reports/tp2-spoon/spoon-coupling.csv");
        Path outputMatrix = Paths.get("target/reports/tp2-spoon/spoon-coupling-matrix.csv");
        Path outputDot = Paths.get("target/reports/tp2-spoon/spoon-coupling.dot");

        System.out.println("Lecture du graphe Spoon depuis : " + inputFile.toAbsolutePath());

        // Chargement des relations à partir du fichier CSV
        List<Edge> edges = loadEdges(inputFile);
        System.out.println("Relations trouvées : " + edges.size());

        // 2) Construction de la matrice de couplage normalisée
        Map<String, Map<String, Double>> matrix = buildMatrix(edges);

        // 3) Export des résultats (matrice CSV + graphe DOT)
        exportMatrixCSV(matrix, outputMatrix);
        CouplingCalculator.exportEdgesDOT(matrix, outputDot, 0.0);

        System.out.println("Matrice de couplage exportée : " + outputMatrix.toAbsolutePath());
        System.out.println("Graphe DOT exporté : " + outputDot.toAbsolutePath());
        System.out.println("Pour visualiser : dot -Tpng target/reports/tp2-spoon/spoon-coupling.dot -o target/reports/tp2-spoon/spoon-coupling.png");
    }

    /**
     * Lecture du fichier CSV généré par Spoon pour extraire les relations de dépendance.
     */
    private static List<Edge> loadEdges(Path csv) throws IOException {
        try (BufferedReader br = Files.newBufferedReader(csv)) {
            return br.lines()
                     .skip(1) // Ignorer l'en-tête ("Source,Target")
                     .map(line -> line.split(","))
                     .filter(parts -> parts.length >= 2)
                     .map(parts -> new Edge(parts[0].trim(), parts[1].trim()))
                     .collect(Collectors.toList());
        }
    }

    /**
     * Construit la matrice de couplage entre toutes les classes du projet.
     */
    private static Map<String, Map<String, Double>> buildMatrix(List<Edge> edges) {
        // Liste des classes impliquées dans au moins une relation
        Set<String> classes = edges.stream()
                                   .flatMap(e -> Stream.of(e.src(), e.dest()))
                                   .collect(Collectors.toCollection(TreeSet::new));

        Map<String, Map<String, Double>> matrix = new TreeMap<>();

        // Calcul du couplage pour chaque paire de classes
        for (String a : classes) {
            matrix.putIfAbsent(a, new TreeMap<>());
            for (String b : classes) {
                if (a.equals(b)) continue;
                double coupling = computeCoupling(a, b, edges);
                matrix.get(a).put(b, coupling);
            }
        }
        return matrix;
    }

    /**
     * Calcule le couplage entre deux classes données.
     */
    private static double computeCoupling(String a, String b, List<Edge> edges) {
        long total = edges.size();
        if (total == 0) return 0.0;

        // Nombre de relations directes entre les deux classes
        long between = edges.stream()
                .filter(e -> (e.src().equals(a) && e.dest().equals(b))
                          || (e.src().equals(b) && e.dest().equals(a)))
                .count();

        return (double) between / total;
    }

    /**
     * Exporte la matrice de couplage au format CSV.
     */
    private static void exportMatrixCSV(Map<String, Map<String, Double>> matrix, Path output) throws IOException {
        Files.createDirectories(output.getParent());
        List<String> classes = new ArrayList<>(matrix.keySet());

        try (BufferedWriter bw = Files.newBufferedWriter(output)) {
            bw.write("Class," + String.join(",", classes) + "\n");
            for (String a : classes) {
                bw.write(a);
                for (String b : classes) {
                    double val = matrix.get(a).getOrDefault(b, 0.0);
                    bw.write("," + String.format(Locale.US, "%.4f", val));
                }
                bw.write("\n");
            }
        }
    }
}
