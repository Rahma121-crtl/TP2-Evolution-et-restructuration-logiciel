package coupling;

import spoon.Launcher;
import spoon.reflect.CtModel;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.declaration.CtType;
import spoon.reflect.reference.CtTypeReference;
import spoon.reflect.visitor.filter.TypeFilter;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

// TP2 – Exercice 3 : Utilisation de Spoon
// Cette classe permet d’analyser le code source avec Spoon pour extraire
// automatiquement les dépendances entre classes et générer le graphe de couplage.
public class SpoonCouplingCalculator {

    public static void main(String[] args) throws Exception {
        // 1) Création et construction du modèle Spoon (analyse du code source)
        Launcher launcher = new Launcher();
        launcher.addInputResource("src/main/java");
        launcher.buildModel();
        CtModel model = launcher.getModel();

        // 2) Initialisation d’une map : classe -> ensemble de classes dépendantes
        Map<String, Set<String>> couplings = new HashMap<>();

        // Parcours de toutes les classes du projet
        for (CtType<?> clazz : model.getAllTypes()) {
            String className = clazz.getQualifiedName();

            // On ne garde que les classes du projet (on ignore les libs externes)
            if (!(className.startsWith("tp2demo.")
               || className.startsWith("coupling.")
               || className.startsWith("graph.")
               || className.startsWith("utils.")
               || className.startsWith("Analysis."))) {
                continue;
            }

            couplings.putIfAbsent(className, new HashSet<>());

            // Recherche des appels de méthodes à partir de chaque classe
            for (CtInvocation<?> inv : clazz.getElements(new TypeFilter<>(CtInvocation.class))) {
                CtTypeReference<?> targetRef = inv.getExecutable().getDeclaringType();
                if (targetRef == null) continue;

                String targetName = targetRef.getQualifiedName();
                if (targetName == null || targetName.equals(className)) continue;

                // On garde uniquement les dépendances internes au projet
                if (targetName.startsWith("tp2demo.")
                 || targetName.startsWith("coupling.")
                 || targetName.startsWith("graph.")
                 || targetName.startsWith("utils.")
                 || targetName.startsWith("Analysis.")) {
                    couplings.get(className).add(targetName);
                }
            }
        }

        // Affichage du graphe de couplage extrait
        System.out.println("=== Graphe de couplage via Spoon (filtré) ===");
        couplings.forEach((src, dests) -> System.out.println(src + " → " + dests));

        // 3) Export des résultats au format CSV
        Path csv = Paths.get("target/reports/tp2-spoon/spoon-coupling.csv");
        exportCouplingCSV(couplings, csv);

        // 4) Export du graphe au format DOT (pour Graphviz)
        Path dot = Paths.get("target/reports/tp2-spoon/spoon-coupling.dot");
        exportCouplingDOT(couplings, dot);

        // 5) Génération de l’image PNG (si Graphviz est installé)
        try {
            new ProcessBuilder("dot", "-Tpng", dot.toString(),
                    "-o", "target/reports/tp2-spoon/spoon-coupling.png")
                    .inheritIO()
                    .start()
                    .waitFor();
            System.out.println("Image générée automatiquement : target/reports/tp2-spoon/spoon-coupling.png");
        } catch (Exception e) {
            System.out.println("Graphviz non détecté. Commande manuelle :");
            System.out.println("dot -Tpng " + dot + " -o target/reports/tp2-spoon/spoon-coupling.png");
        }
    }

    // Fonctions utilitaires

    /**
     * Exporte le graphe de couplage au format CSV (Source, Target)
     */
    private static void exportCouplingCSV(Map<String, Set<String>> couplings, Path file) throws IOException {
        Files.createDirectories(file.getParent());
        List<String> lines = new ArrayList<>();
        lines.add("Source,Target");
        couplings.forEach((src, dests) -> dests.forEach(d -> lines.add(src + "," + d)));
        Files.write(file, lines);
        System.out.println("Exporté (CSV) : " + file.toAbsolutePath());
    }

    /**
     * Exporte le graphe de couplage au format DOT (pour visualisation Graphviz)
     */
    private static void exportCouplingDOT(Map<String, Set<String>> couplings, Path dotFile) throws IOException {
        Files.createDirectories(dotFile.getParent());
        try (BufferedWriter bw = Files.newBufferedWriter(dotFile)) {
            bw.write("digraph Coupling {\n");
            bw.write("  layout=sfdp;\n");
            bw.write("  overlap=false;\n");
            bw.write("  splines=true;\n");
            bw.write("  node [shape=ellipse, style=filled, fillcolor=\"#d9f2e6\", fontsize=12];\n");
            bw.write("  edge [color=gray50, fontcolor=black, fontsize=10];\n");

            // Ajout des relations (arêtes du graphe)
            for (Map.Entry<String, Set<String>> e : couplings.entrySet()) {
                for (String t : e.getValue()) {
                    bw.write("  \"" + e.getKey() + "\" -> \"" + t + "\";\n");
                }
            }
            bw.write("}\n");
        }
        System.out.println("Graphe DOT exporté : " + dotFile.toAbsolutePath());
    }
}
