package coupling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.Set;
import java.util.TreeSet;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * TP2 - Exercice 1 : Graphe de couplage entre classes 
 * Cette classe permet de lire le graphe d’appel (CSV), calculer le couplage
 * entre les classes, construire la matrice et générer les exports CSV/DOT.
 */
public class CouplingCalculator {

    /** Représente une arête (appel) entre deux classes */
    public static record Edge(String callerClass, String callerMethod,
                              String calleeClass, String calleeMethod,
                              int count) {}

    // 1) CHARGEMENT DU CSV
    /**
     * Charge les arêtes depuis un fichier CSV et détecte le format du fichier.
     */
    public static List<Edge> loadEdges(Path csv) {
        List<Edge> edges = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(csv)) {
            String header = br.readLine();
            if (header == null) return edges;

            String h = header.trim().toLowerCase(Locale.ROOT);

            // On détecte le format du CSV (2, 3 ou 5 colonnes)
            boolean isFiveCols = h.startsWith("callerclass,callermethod");
            boolean isThreeCols = h.startsWith("callerclass,calleeclass");
            boolean isTwoCols   = h.startsWith("caller,callee");

            String line;
            while ((line = br.readLine()) != null) {
                if (line.isBlank()) continue;
                String[] p = line.split(",");

                // Format complet (5 colonnes)
                if (isFiveCols) {
                    if (p.length < 5) continue;
                    edges.add(new Edge(
                            p[0].trim(), p[1].trim(),
                            p[2].trim(), p[3].trim(),
                            parseIntSafe(p[4].trim(), 1)
                    ));
                } 
                // Format intermédiaire (3 colonnes)
                else if (isThreeCols) {
                    if (p.length < 2) continue;
                    String callerClass = p[0].trim();
                    String calleeClass = p[1].trim();
                    int count = (p.length >= 3) ? parseIntSafe(p[2].trim(), 1) : 1;
                    edges.add(new Edge(callerClass, "*", calleeClass, "*", count));
                } 
                // Format simple (2 colonnes)
                else if (isTwoCols) {
                    if (p.length < 2) continue;
                    String caller = p[0].trim();
                    String callee = p[1].trim();
                    edges.add(new Edge(caller, "*", callee, "*", 1));
                } 
                // Cas par défaut : détection heuristique
                else {
                    if (p.length == 5) {
                        edges.add(new Edge(p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim(),
                                parseIntSafe(p[4].trim(), 1)));
                    } else if (p.length >= 2) {
                        String callerClass = p[0].trim();
                        String calleeClass = p[1].trim();
                        int count = (p.length >= 3) ? parseIntSafe(p[2].trim(), 1) : 1;
                        edges.add(new Edge(callerClass, "*", calleeClass, "*", count));
                    }
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Erreur lecture CSV: " + csv, e);
        }
        return edges;
    }

    /** Convertit une chaîne en entier sans lever d’erreur */
    private static int parseIntSafe(String s, int def) {
        try { return Integer.parseInt(s); } catch (Exception e) { return def; }
    }

    // 2) COUPLAGE ENTRE CLASSES
    /**
     * Calcule le couplage entre deux classes A et B à partir des arêtes.
     */
    public static double couplingAB(String A, String B, List<Edge> edges) {
        if (A.equals(B)) return 0.0;

        // Total des appels inter-classes
        long interTotal = edges.stream()
                .filter(e -> !e.callerClass.equals(e.calleeClass))
                .mapToLong(e -> e.count)
                .sum();
        if (interTotal == 0) return 0.0;

        // Nombre d’appels entre A et B
        long ab = edges.stream()
                .filter(e ->
                        (e.callerClass.equals(A) && e.calleeClass.equals(B)) ||
                        (e.callerClass.equals(B) && e.calleeClass.equals(A))
                )
                .mapToLong(e -> e.count)
                .sum();

        return (double) ab / (double) interTotal;
    }

    // 3) MATRICE DE COUPLAGE
       /**
     * Construit la matrice de couplage entre toutes les classes du projet.
     * On filtre pour ne garder que les packages du projet.
     */
    public static Map<String, Map<String, Double>> buildMatrix(List<Edge> edges) {
        Set<String> classes = edges.stream()
                .flatMap(e -> Stream.of(e.callerClass, e.calleeClass))
                // On garde seulement les classes du projet (et on ignore les libs)
                .filter(c -> (c.startsWith("Analysis.") ||
                              c.startsWith("graph.") ||
                              c.startsWith("coupling.") ||
                              c.startsWith("utils.") ||
                              c.startsWith("tp2demo.")) &&
                             !(c.startsWith("java.") ||
                               c.startsWith("org.eclipse.") ||
                               c.startsWith("spoon.")))
                .collect(Collectors.toCollection(TreeSet::new));

        Map<String, Map<String, Double>> matrix = new TreeMap<>();
        for (String a : classes) {
            Map<String, Double> row = new TreeMap<>();
            for (String b : classes) {
                if (!a.equals(b))
                    row.put(b, couplingAB(a, b, edges));
            }
            matrix.put(a, row);
        }
        return matrix;
    }

     // 4) EXPORTS DES RÉSULTATS
       /** Exporte la matrice de couplage dans un fichier CSV */
    public static void exportMatrixCSV(Map<String, Map<String, Double>> M, Path out) {
        try {
            Files.createDirectories(out.getParent());
            List<String> classes = new ArrayList<>(M.keySet());
            try (BufferedWriter bw = Files.newBufferedWriter(out)) {
                bw.write("Class," + String.join(",", classes));
                bw.newLine();
                for (String a : classes) {
                    String row = classes.stream()
                            .map(b -> a.equals(b) ? "0"
                                    : String.format(Locale.ROOT, "%.6f",
                                      M.getOrDefault(a, Map.of()).getOrDefault(b, 0.0)))
                            .collect(Collectors.joining(","));
                    bw.write(a + "," + row);
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /** Exporte le graphe pondéré au format DOT (pour Graphviz) */
    public static void exportEdgesDOT(Map<String, Map<String, Double>> M, Path outDot, double threshold) {
        try (BufferedWriter bw = Files.newBufferedWriter(outDot)) {
            bw.write("graph Coupling {\n");
            // Paramètres visuels du graphe
            bw.write("  layout=sfdp;\n");
            bw.write("  overlap=false;\n");
            bw.write("  splines=true;\n");
            bw.write("  K=3;\n");
            bw.write("  sep=1.5;\n");
            bw.write("  nodesep=2.0;\n");
            bw.write("  ranksep=2.0;\n");
            bw.write("  margin=0.5;\n");
            bw.write("  fontsize=12;\n");
            bw.write("  fontname=\"Helvetica\";\n");
            bw.write("  bgcolor=\"white\";\n");
            bw.write("  node [shape=ellipse, style=filled, fillcolor=\"#d9f2e6\", fontsize=12, width=1.5, height=0.8];\n");
            bw.write("  edge [color=gray40, fontcolor=black, fontsize=10, penwidth=1.2];\n");

            // Ajout des nœuds
            for (String a : M.keySet()) {
                bw.write("  \"" + a + "\";\n");
            }

            // Ajout des arêtes pondérées
            for (String a : M.keySet()) {
                for (Map.Entry<String, Double> e : M.get(a).entrySet()) {
                    String b = e.getKey();
                    double w = e.getValue();
                    if (a.compareTo(b) < 0 && w >= threshold) {
                        bw.write("  \"" + a + "\" -- \"" + b + "\" [label=\"" +
                                 String.format(Locale.ROOT, "%.3f", w) + "\"];\n");
                    }
                }
            }
            bw.write("}\n");
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    // 5) MAIN (EXÉCUTION)
      /**
     * Point d’entrée du programme : charge le CSV, calcule la matrice
     * et génère les fichiers résultats.
     */
    public static void main(String[] args) {
        Path csv = Paths.get("target/reports/tp2-callgraph/callgraph-edges.csv");
        List<Edge> edges = loadEdges(csv);
        System.out.println("Arêtes chargées: " + edges.size());

        String A = "tp2demo.Person";
        String B = "tp2demo.Car";
        System.out.println("Couplage(" + A + "," + B + ") = " + couplingAB(A, B, edges));

        Map<String, Map<String, Double>> matrix = buildMatrix(edges);
        exportMatrixCSV(matrix, Paths.get("target/reports/tp2-coupling/coupling-matrix.csv"));
        exportEdgesDOT(matrix, Paths.get("target/reports/tp2-coupling/coupling.dot"), 0.0);

        System.out.println("Fichiers générés dans reports/tp2-coupling/");
    }
}
