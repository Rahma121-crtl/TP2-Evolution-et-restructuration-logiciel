package coupling;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import spoon.Launcher;
import spoon.reflect.CtModel;
import spoon.reflect.declaration.CtClass;
import spoon.reflect.visitor.filter.TypeFilter;
import spoon.reflect.code.CtInvocation;

/**
 * TP2 – Exercice 3 : Clustering des classes à partir de Spoon
 *
 * Cette classe utilise la bibliothèque Spoon pour analyser le code source
 * et construire une matrice de couplage simple entre les classes du projet.
 * Elle exporte ensuite les résultats sous forme de fichier CSV.
 */
public class SpoonModuleClustering {

    /** Matrice des couplages entre les classes détectées par Spoon */
    private final Map<String, Map<String, Double>> couplingMatrix = new LinkedHashMap<>();

    /**
     * Analyse le projet avec Spoon et calcule les relations entre classes.
     * Chaque appel de méthode entre deux classes est compté comme une dépendance.
     */
    public void analyzeWithSpoon(Path srcPath) {
        Launcher launcher = new Launcher();
        launcher.addInputResource(srcPath.toString());
        launcher.buildModel();
        CtModel model = launcher.getModel();

        // Liste des classes trouvées dans le modèle
        List<CtClass<?>> classes = model.getElements(new TypeFilter<>(CtClass.class));

        // Pour chaque classe du projet
        for (CtClass<?> cls : classes) {
            String className = cls.getQualifiedName();
            couplingMatrix.putIfAbsent(className, new LinkedHashMap<>());

            // Recherche des appels de méthodes depuis cette classe
            for (CtInvocation<?> inv : cls.getElements(new TypeFilter<>(CtInvocation.class))) {
                if (inv.getExecutable().getDeclaringType() != null) {
                    String target = inv.getExecutable().getDeclaringType().getQualifiedName();
                    // On ignore les auto-appels (une classe qui s'appelle elle-même)
                    if (!target.equals(className)) {
                        // On incrémente le compteur de dépendance
                        couplingMatrix.get(className)
                            .merge(target, 1.0, Double::sum);
                    }
                }
            }
        }
        System.out.println("Analyse Spoon terminée : " + couplingMatrix.size() + " classes.");
    }

    /**
     * Exporte la matrice de couplage obtenue dans un fichier CSV.
     */
    public void exportMatrixCSV(Path out) throws IOException {
        Files.createDirectories(out.getParent());
        List<String> classes = new ArrayList<>(couplingMatrix.keySet());
        try (BufferedWriter bw = Files.newBufferedWriter(out)) {
            bw.write("Class," + String.join(",", classes));
            bw.newLine();
            for (String a : classes) {
                StringBuilder sb = new StringBuilder(a);
                for (String b : classes) {
                    sb.append(",").append(couplingMatrix.getOrDefault(a, Map.of()).getOrDefault(b, 0.0));
                }
                bw.write(sb.toString());
                bw.newLine();
            }
        }
        System.out.println("Matrice exportée : " + out);
    }

    /**
     * Méthode principale : lance l’analyse Spoon sur le package tp2demo
     * et exporte la matrice correspondante.
     */
    public static void main(String[] args) throws Exception {
        SpoonModuleClustering smc = new SpoonModuleClustering();
        smc.analyzeWithSpoon(Path.of("src/main/java/tp2demo"));
        smc.exportMatrixCSV(Path.of("target/reports/tp2-spoon/spoon-coupling-matrix.csv"));
    }
}
