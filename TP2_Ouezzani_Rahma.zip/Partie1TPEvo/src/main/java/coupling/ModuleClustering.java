package coupling;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * TP2 - Exercice 2 : Clustering hiérarchique des classes
 *
 * Cette classe permet de regrouper les classes fortement couplées
 * afin de former des modules plus cohérents à partir de la matrice de couplage.
 */
public class ModuleClustering {

    /** Matrice des couplages calculée entre les classes */
    private final Map<String, Map<String, Double>> matrix = new LinkedHashMap<>();

    /** Copie de la matrice d’origine pour vérifier les moyennes finales */
    private Map<String, Map<String, Double>> originalMatrix;

   // 1. LECTURE DE LA MATRICE CSV
    /**
     * Charge la matrice de couplage à partir du fichier CSV généré
     * par l’exercice précédent.
     */
    public void loadMatrix(Path file) throws IOException {
        originalMatrix = new LinkedHashMap<>();

        try (BufferedReader br = Files.newBufferedReader(file)) {
            String header = br.readLine();
            if (header == null) return;
            String[] classes = header.split(",");

            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String classA = parts[0].trim();
                Map<String, Double> row = new LinkedHashMap<>();
                for (int j = 1; j < parts.length; j++) {
                    double value = 0.0;
                    try { value = Double.parseDouble(parts[j]); }
                    catch (NumberFormatException ignored) {}
                    row.put(classes[j], value);
                }
                matrix.put(classA, new LinkedHashMap<>(row));
                originalMatrix.put(classA, new LinkedHashMap<>(row));
            }
        }
        System.out.println(" Matrice de couplage chargée (" + matrix.size() + " classes)");
    }

   // 2. EXPORT DES MODULES
     /**
     * Exporte la liste des modules finaux dans un fichier CSV.
     */
    public void exportModulesCSV(Path file) {
        try {
            List<String> lines = new ArrayList<>();
            lines.add("Module");
            for (String cluster : matrix.keySet()) {
                lines.add(cluster);
            }
            Files.write(file, lines);
            System.out.println(" Modules exportés dans : " + file.toAbsolutePath());
        } catch (IOException e) {
            throw new RuntimeException("Erreur lors de l'export CSV", e);
        }
    }

    // 3. TROUVER LE COUPLAGE MAX
    /**
     * Recherche la paire de classes (ou clusters) ayant le plus fort couplage.
     */
    private String[] findMostCoupledPair() {
        String bestA = null, bestB = null;
        double bestValue = -1.0;

        for (String a : matrix.keySet()) {
            for (String b : matrix.get(a).keySet()) {
                if (a.equals(b)) continue;
                double v = matrix.get(a).get(b);
                if (v > bestValue) {
                    bestValue = v;
                    bestA = a;
                    bestB = b;
                }
            }
        }

        System.out.printf("🔹 Meilleur couplage trouvé : %s ↔ %s = %.4f%n", bestA, bestB, bestValue);
        return new String[]{bestA, bestB};
    }

     // 4. FUSION DE CLUSTERS
    /**
     * Fusionne deux clusters (a et b) en un seul module en moyennant
     * leurs valeurs de couplage avec les autres classes.
     */
    private void mergeClusters(String a, String b) {
        String merged = a + "+" + b;
        Map<String, Double> newRow = new LinkedHashMap<>();

        // Calcul de la moyenne des couplages entre les deux clusters fusionnés
        for (String other : matrix.keySet()) {
            if (other.equals(a) || other.equals(b)) continue;
            double val = (matrix.get(a).getOrDefault(other, 0.0)
                        + matrix.get(b).getOrDefault(other, 0.0)) / 2.0;
            newRow.put(other, val);
        }

        // Suppression des anciens clusters
        matrix.remove(a);
        matrix.remove(b);
        for (Map<String, Double> row : matrix.values()) {
            row.remove(a);
            row.remove(b);
        }

        // Ajout du nouveau cluster fusionné
        matrix.put(merged, newRow);
        for (String other : newRow.keySet()) {
            matrix.get(other).put(merged, newRow.get(other));
        }

        System.out.println("🔸 Fusion : " + a + " + " + b + " → " + merged);
    }

   // 5. EXECUTION DU CLUSTERING
    /**
     * Exécute l’algorithme de clustering hiérarchique.
     * Les fusions continuent jusqu’à atteindre un seuil ou un nombre max de modules.
     */
    public void performClustering(double threshold, int maxClusters) {
        int nbClasses = matrix.size();
        double cp = threshold;
        System.out.printf("M=%d, CP=%.3f, maxClusters=%d%n", nbClasses, cp, maxClusters);

        // Boucle principale du clustering
        while (matrix.size() > maxClusters) {
            String[] bestPair = findMostCoupledPair();
            String a = bestPair[0];
            String b = bestPair[1];

            if (a == null || b == null) break;
            double bestValue = matrix.get(a).get(b);
            if (bestValue < threshold) break;

            mergeClusters(a, b);
        }

        // Résumé final des modules
        System.out.println("\n Clustering terminé. Nombre final de modules : " + matrix.size());
        System.out.println("Modules identifiés :");
        for (String cluster : matrix.keySet()) {
            System.out.println(" - " + cluster);
        }

        // Vérification de la cohérence interne des modules
        System.out.println("\n Vérification des moyennes intra-modules :");
        for (String cluster : matrix.keySet()) {
            double avg = avgIntraCoupling(cluster, originalMatrix);
            System.out.printf("   Module %-40s Moyenne intra = %.4f%n", cluster, avg);
        }
    }

    // 6. CALCUL MOYENNE INTRA-MODULE
    /**
     * Calcule la moyenne des couplages entre les classes d’un même module.
     */
    private static double avgIntraCoupling(String clusterName, Map<String, Map<String, Double>> original) {
        String[] classes = clusterName.split("\\+");
        int n = classes.length;
        if (n <= 1) return 0.0;

        double sum = 0.0;
        int count = 0;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                sum += original.getOrDefault(classes[i], Map.of())
                               .getOrDefault(classes[j], 0.0);
                sum += original.getOrDefault(classes[j], Map.of())
                               .getOrDefault(classes[i], 0.0);
                count += 2;
            }
        }
        return (count == 0) ? 0.0 : sum / count;
    }

     // 7. MAIN (TEST)
    /**
     * Méthode principale pour tester le clustering.
     * On exécute deux cas : sans fusion et avec fusion.
     */
    public static void main(String[] args) throws Exception {
        Path csv = Path.of("target/reports/tp2-spoon/spoon-coupling-matrix.csv");
        ModuleClustering mc = new ModuleClustering();
        mc.loadMatrix(csv);

        // Premier test : sans fusion (CP=0)
        mc.performClustering(0.0, 34);

        // Deuxième test : avec fusion (CP=0.01)
        mc.performClustering(0.01, 2);

        // Export final des modules
        mc.exportModulesCSV(Path.of("target/reports/tp2-spoon/spoon-modules.csv"));
    }
}
