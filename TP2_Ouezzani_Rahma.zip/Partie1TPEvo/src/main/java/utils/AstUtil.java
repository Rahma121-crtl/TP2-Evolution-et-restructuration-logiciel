package utils;

import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;

import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Classe utilitaire pour la manipulation de l’AST avec JDT.
 * Fournit des fonctions pour :
 *  - Lister les fichiers Java
 *  - Parser un fichier en CompilationUnit
 *  - Compter les lignes de code sans commentaires
 */
public final class AstUtil {

    /** Dossier racine des sources à analyser */
    public static Path SOURCE_ROOT = Paths.get("src/main/java");

    private AstUtil() {}

    /** Liste récursivement tous les fichiers .java à partir d’un dossier */
    public static List<Path> listJavaFiles(Path root) {
        try (Stream<Path> s = Files.walk(root)) {
            return s.filter(p -> p.toString().endsWith(".java")).collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /** Parse un fichier Java en AST (CompilationUnit) avec résolution des types */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static CompilationUnit parse(char[] classSource, Path file) {
        try {
            ASTParser parser = ASTParser.newParser(AST.JLS17);
            parser.setResolveBindings(true);
            parser.setKind(ASTParser.K_COMPILATION_UNIT);
            parser.setBindingsRecovery(true);

            Map options = JavaCore.getOptions();
            JavaCore.setComplianceOptions(JavaCore.VERSION_17, options);
            parser.setCompilerOptions(options);

            parser.setUnitName(file.getFileName().toString());
            String[] sources = { SOURCE_ROOT.toAbsolutePath().toString() };
            String[] classpath = { Paths.get("target/classes").toAbsolutePath().toString() };
            parser.setEnvironment(classpath, sources, new String[] { "UTF-8" }, true);

            parser.setSource(classSource);
            return (CompilationUnit) parser.createAST(null);
        } catch (Exception e) {
            throw new RuntimeException("Parse failed for " + file, e);
        }
    }

    // Expressions régulières pour les commentaires
    private static final Pattern LINE_COMMENT  = Pattern.compile("//.*?$", Pattern.MULTILINE);
    private static final Pattern BLOCK_COMMENT = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);

    /** Supprime les commentaires d’un code source */
    public static String stripComments(String source) {
        String no = LINE_COMMENT.matcher(source).replaceAll("");
        return BLOCK_COMMENT.matcher(no).replaceAll("");
    }

    /** Compte les lignes de code sans commentaires */
    public static long countLOCNoComments(String source) {
        String no = stripComments(source);
        return no.lines().map(String::trim).filter(l -> !l.isEmpty()).count();
    }

    /** Compte les lignes de code dans un corps de méthode */
    public static long countLOCBody(String bodySource) {
        String no = stripComments(bodySource);
        return no.lines()
                 .map(String::trim)
                 .filter(l -> !l.isEmpty())
                 .filter(l -> !l.equals("{") && !l.equals("}"))
                 .count();
    }
}
