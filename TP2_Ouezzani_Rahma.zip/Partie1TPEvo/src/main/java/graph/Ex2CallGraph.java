package graph;

import org.eclipse.jdt.core.dom.*;
import utils.AstUtil;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * TP2 – Exercice 1 : Construction du graphe d’appel entre classes
 *
 * Cette classe parcourt les fichiers source Java à l’aide de l’API JDT (AST)
 * afin d’identifier les appels entre classes (pas entre méthodes individuelles).
 * Elle génère ensuite un graphe d’appel au format DOT et CSV.
 */
public class Ex2CallGraph {

    public static void main(String[] args) throws Exception {
        // Dossier contenant les fichiers source à analyser
        Path srcPath = AstUtil.SOURCE_ROOT;
        boolean showGui = false;

        // Lecture des arguments 
        // ou d'activer l'affichage graphique (--gui)
        for (String a : args) {
            if (a.startsWith("--src=")) {
                srcPath = Paths.get(a.substring("--src=".length()));
            } else if ("--gui".equalsIgnoreCase(a)) {
                showGui = true;
            }
        }

        // Liste de tous les fichiers Java à analyser
        List<Path> files = AstUtil.listJavaFiles(srcPath);
        Map<String, Map<String, Integer>> graph = new LinkedHashMap<>();

        // Parcours de chaque fichier source du projet
        for (Path file : files) {
            String content = Files.readString(file);
            CompilationUnit cu = AstUtil.parse(content.toCharArray(), file);

            String pkg = (cu.getPackage() == null) ? "<default>"
                    : cu.getPackage().getName().getFullyQualifiedName();

            // Visiteur d'AST : parcourt la structure syntaxique du code
            cu.accept(new ASTVisitor() {
                @Override public boolean visit(TypeDeclaration type) {
                    if (type.isInterface()) return true;
                    String className = pkg.equals("<default>") ? type.getName().getIdentifier()
                            : pkg + "." + type.getName().getIdentifier();

                    // Recherche des appels internes à la classe
                    type.accept(new ASTVisitor() {
                        @Override public boolean visit(MethodInvocation node) {
                            String calleeType = resolveType(node);
                            addEdge(graph, className, calleeType);
                            return true;
                        }

                        @Override public boolean visit(SuperMethodInvocation node) {
                            IMethodBinding mb = node.resolveMethodBinding();
                            if (mb != null && mb.getDeclaringClass() != null)
                                addEdge(graph, className, mb.getDeclaringClass().getQualifiedName());
                            return true;
                        }

                        @Override public boolean visit(ClassInstanceCreation node) {
                            ITypeBinding tb = node.resolveTypeBinding();
                            if (tb != null)
                                addEdge(graph, className, tb.getQualifiedName());
                            return true;
                        }

                        // Détermine le type de la classe appelée dans un appel de méthode
                        private String resolveType(MethodInvocation inv) {
                            IMethodBinding mb = inv.resolveMethodBinding();
                            if (mb != null && mb.getDeclaringClass() != null)
                                return mb.getDeclaringClass().getQualifiedName();
                            if (inv.getExpression() != null) {
                                ITypeBinding tb = inv.getExpression().resolveTypeBinding();
                                if (tb != null) return tb.getQualifiedName();
                            }
                            return "<inconnu>";
                        }
                    });
                    return true;
                }
            });
        }

        // Nettoyage du graphe : suppression des dépendances vers les bibliothèques externes
        cleanGraph(graph);

        // Préparation des fichiers de sortie (CSV et DOT)
        Path reportsDir = Paths.get("target/reports/tp2-callgraph");
        Files.createDirectories(reportsDir);

        Path csvFile = reportsDir.resolve("callgraph-edges.csv");
        Path dotFile = reportsDir.resolve("callgraph.dot");

        // Export des résultats
        exportEdgesCSV(graph, csvFile);
        exportDot(graph, dotFile);

        // Informations de fin d’exécution
        System.out.println("Graphe d’appel généré !");
        System.out.println(" - CSV : " + csvFile.toAbsolutePath());
        System.out.println(" - DOT : " + dotFile.toAbsolutePath());
        System.out.println("Pour visualiser : dot -Tpng " + dotFile.getFileName() + " -o callgraph.png");
    }

    /**
     * Ajoute une relation (arête) entre deux classes appelantes et appelées.
     * Les appels internes ou vers des classes externes sont ignorés.
     */
    private static void addEdge(Map<String, Map<String, Integer>> graph, String caller, String callee) {
        if (callee == null || caller.equals(callee)) return;
        if (callee.startsWith("java.") || callee.startsWith("javax.") ||
            callee.startsWith("org.eclipse.") || callee.equals("<inconnu>")) return;

        graph.computeIfAbsent(caller, k -> new LinkedHashMap<>());
        graph.get(caller).merge(callee, 1, Integer::sum);
    }

    /**
     * Supprime les classes externes du graphe (Java, Eclipse, etc.)
     * pour ne garder que les dépendances internes au projet.
     */
    private static void cleanGraph(Map<String, Map<String, Integer>> graph) {
        graph.keySet().removeIf(cls ->
                cls.startsWith("java.") || cls.startsWith("javax.") || cls.startsWith("org.eclipse."));
        graph.values().forEach(m ->
                m.keySet().removeIf(t ->
                        t.startsWith("java.") || t.startsWith("javax.") || t.startsWith("org.eclipse.")));
    }

    /**
     * Exporte le graphe d’appel au format CSV (caller, callee, count).
     */
    private static void exportEdgesCSV(Map<String, Map<String, Integer>> graph, Path file) throws IOException {
        List<String> lines = new ArrayList<>();
        lines.add("callerClass,calleeClass,count");
        graph.forEach((caller, callees) ->
                callees.forEach((callee, count) ->
                        lines.add(String.join(",", caller, callee, String.valueOf(count)))));
        Files.write(file, lines);
    }

    /**
     * Exporte le graphe d’appel au format DOT pour visualisation avec Graphviz.
     */
    private static void exportDot(Map<String, Map<String, Integer>> graph, Path file) throws IOException {
        StringBuilder sb = new StringBuilder("digraph CallGraph {\n");
        sb.append("  rankdir=LR;\n  node [shape=box, style=filled, color=lightblue];\n");
        for (var entry : graph.entrySet()) {
            String caller = entry.getKey();
            for (var e : entry.getValue().entrySet()) {
                sb.append("  \"" + caller + "\" -> \"" + e.getKey() + "\" [label=\"" + e.getValue() + "\"];\n");
            }
        }
        sb.append("}\n");
        Files.writeString(file, sb.toString());
    }
}
