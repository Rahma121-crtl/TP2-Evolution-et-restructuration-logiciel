package tp2demo;

public class Car {
    private Engine engine;

    public void start() {
        engine = new Engine();
        engine.run();
    }

    public void park() {
        System.out.println("Car parked.");
    }
}
