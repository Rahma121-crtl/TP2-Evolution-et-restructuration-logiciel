package tp2demo;

public class Person {
    private Car car;
    private Bike bike;

    public void drive() {
        car = new Car();
        car.start();
    }

    public void ride() {
        bike = new Bike();
        bike.start();
    }
}
