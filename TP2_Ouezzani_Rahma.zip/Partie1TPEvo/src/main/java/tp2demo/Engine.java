package tp2demo;

public class Engine {
    public void run() {
        System.out.println("Engine running...");
    }
}
