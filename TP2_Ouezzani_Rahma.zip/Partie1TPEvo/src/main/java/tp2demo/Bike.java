package tp2demo;

public class Bike {
    public void start() {
        System.out.println("Bike started.");
    }
}
